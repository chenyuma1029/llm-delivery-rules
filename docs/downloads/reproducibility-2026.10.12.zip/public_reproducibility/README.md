# Delivery Rules and Method Choice under Hard Communication Budgets

Reproducibility materials for **Delivery Rules and Method Choice in LLM Collaboration under Hard Communication Budgets**, by Chenyu Ma, Xuechen Chen, and Feng Wang.

The study compares terminal delivery rules using frozen MATH and MMLU-Pro outputs from 700 tasks and 156 synthetic budget settings. The repository contains an aggregate comparison interface and a compact task-level statistical dataset. No language-model calls or evaluator reference answers are needed to run either.

## Contents

| Directory | Purpose |
|---|---|
| `audit_report/` | Aggregate score/resource checks and method comparisons |
| `statistics/` | Anonymous derived task metrics, folds, selection and interval scripts |
| `analysis_summary/` | All declared completion thresholds, grid strata, and split results |
| `heldout_summary/` | Original held-out aggregate results |
| `tools/` | Deterministic presentation-figure generation |

## Aggregate audit

Use Python 3.12 or later, from the repository root:

```sh
python3 -m unittest discover -s audit_report -v
python3 audit_report/delivery_contract_audit.py --contract audit_report/inputs/contract.json --scores audit_report/inputs/scores.csv --resources audit_report/inputs/resources.csv --out aggregate_reproduced
```

Expected: 9 tests, 936 comparison rows, 49 strict/partial best-set changes, and 67 changes when the separate profile-known preflight comparison is included. The validator checks declared aggregate coverage and arithmetic. Aggregate rows alone cannot establish unique task membership.

## Statistical reproduction

Install the pinned NumPy dependency in `statistics/requirements.txt`, then follow `statistics/README.md`. Eight boundary tests cover selection and completion filtering. The scripts refit the original and added selectors, recompute fixed-OOF conditional intervals, and evaluate all 20 alternate partitions.

The main reverse difference is 7.405 percentage points for all nine configurations, 0.259 for exactly four solver calls, and 2.690 for at most four. Completion thresholds of 90%, 95%, and 99% leave residuals of 0.090, 0.042, and 0.417 points. These exploratory diagnostics are conditional on the specified tasks, configurations, and synthetic grid.

## Presentation figures

```sh
python3 -m pip install -r requirements-plotting.txt
python3 tools/generate_story_assets.py --source-root . --output-root regenerated_assets
```

The script creates two vector figures and three original concise tables from the included aggregate results. It does not regenerate every historical figure or perform inference calls. An additional table-generation script in `tools/generate_final_tables.py` reconstructs the new numerical tables from `analysis_summary/`.

## Scope and citation

Failures remain in the full task denominator. A/B groups are averaged within task; AO-SC8 uses its one shared AB result. Dataset weights are equal. Conditional bootstrap intervals hold OOF choices fixed; alternate split ranges are not population confidence intervals. The 156 contexts are dependent settings, not sampled deployment environments.

Question text, raw generated answers, evaluator references, original task identifiers, private reviews, and correspondence are excluded. Derived task arrays do not establish the correctness of the original reference grading or replace raw-message replay. See CITATION.cff and LICENSE_SCOPE.md for attribution and permitted use.
